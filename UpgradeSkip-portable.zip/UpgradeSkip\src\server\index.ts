import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { serve } from '@hono/node-server';
import { serveStatic } from '@hono/node-server/serve-static';
import { createApp } from './app.js';
import { DEFAULT_PATH, openDatabase } from './db.js';

const port = Number(process.env.PORT ?? 8787);
const dbPath = process.env.DB_PATH ?? DEFAULT_PATH;
const distDir = process.env.STATIC_DIR ?? join(process.cwd(), 'dist');
const serveUi = process.env.SERVE_UI !== '0' && existsSync(join(distDir, 'index.html'));

const db = openDatabase(dbPath);
const app = createApp(db, {
  corsOrigins: [
    'http://localhost:5173',
    'http://127.0.0.1:5173',
    `http://localhost:${port}`,
    `http://127.0.0.1:${port}`,
  ],
});

if (serveUi) {
  app.use('/*', serveStatic({ root: distDir }));
  app.get('*', serveStatic({ path: join(distDir, 'index.html') }));
}

serve({ fetch: app.fetch, port }, (info) => {
  console.log(`UpgradeSkip running at http://localhost:${info.port}`);
  console.log(`Database: ${dbPath}`);
  if (serveUi) {
    console.log(`UI: served from ${distDir}`);
  } else {
    console.log('UI: not found (run npm run build, or use npm run launch / START.bat)');
  }
});
