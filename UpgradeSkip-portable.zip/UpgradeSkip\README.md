# UpgradeSkip — Inventory Delta Advisor

Check what you're thinking of buying against what you already own.

**Non-developers:** open **[START-HERE.md](./START-HERE.md)** and double-click **`START.bat`** (Windows).

Runs fully on your machine — no Vercel / cloud account required.

---

## Quick start (everyone)

| Step | Action |
|---|---|
| 1 | Install [Node.js LTS](https://nodejs.org) (once) |
| 2 | Windows: double-click `START.bat` · Mac: `./start.sh` |
| 3 | Browser opens → http://localhost:8787 |

Share with a teammate:

```bash
npm run pack
```

→ creates `UpgradeSkip-portable.zip`

---

## Developers

```bash
npm install
npm run host          # build + serve UI+API on :8787
npm run dev:all       # hot reload (UI :5173, API :3001)
npm start             # serve existing build
```

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | `8787` | Listen port (`START` auto-picks another if busy) |
| `DB_PATH` | `data/app.db` | Local SQLite file |

| Folder | Role |
|---|---|
| `src/app` | React UI |
| `src/core` | Decide / compare engine |
| `src/server` | API + SQLite |
| `src/db` | Schema + mappers |
| `scripts/` | Launch + zip helpers |

## Troubleshooting

See **START-HERE.md**. Common fixes:

- Install Node LTS and restart the PC
- Windows native build errors → Visual Studio Build Tools (“Desktop development with C++”)
- Port busy → launcher chooses the next free port; use the URL it prints
